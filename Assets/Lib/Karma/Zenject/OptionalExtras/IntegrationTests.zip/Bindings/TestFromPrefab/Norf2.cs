using UnityEngine;

namespace Zenject.Tests.Bindings.FromPrefab
{
    public class Norf2 : MonoBehaviour, INorf
    {
    }
}

